/** @brief fichero de implementacion de la clase fecha

*/
fecha::fecha(){
  // @todo implementar esta funcion
}

fecha::fecha(const fecha & x){
 // @todo implementar esta funcion
}
  
    
 
 ostream& operator<< ( ostream& os, const fecha & f){
   // @todo implementa esta funcion
     
   // os << f.getYear() ;
   return os;
 }
   
   
 
